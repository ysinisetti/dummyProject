export class Test
{
    name:any;
    username:any;
    gender:any;
    password:any;
    cpassword:any;
    language1:any;
    language2:any;
    language3:any;
    language4:any;
    date:any;
    file:any;
}