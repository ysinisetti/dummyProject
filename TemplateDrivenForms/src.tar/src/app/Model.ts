export class Model
{
    Name:any;
    Age:any;
    Id:any;
}