import { Component, OnInit } from '@angular/core'
import { FormGroup, FormBuilder, Validators } from '@angular/forms'

@Component({
  selector: 'app-statustracker',
  templateUrl: './statustracker.component.html',
  styleUrls: ['./statustracker.component.scss'],
})
export class StatustrackerComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
