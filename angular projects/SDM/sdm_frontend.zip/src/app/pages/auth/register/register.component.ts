import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-register-page',
  templateUrl: './register.component.html',
})
export class RegisterPage {}
