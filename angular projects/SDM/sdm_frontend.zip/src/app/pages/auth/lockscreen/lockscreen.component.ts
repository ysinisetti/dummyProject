import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-lockscreen-page',
  templateUrl: './lockscreen.component.html',
})
export class LockscreenPage {}
