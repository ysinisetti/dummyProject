import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-404-page',
  templateUrl: './404.component.html',
})
export class Error404Page {}
