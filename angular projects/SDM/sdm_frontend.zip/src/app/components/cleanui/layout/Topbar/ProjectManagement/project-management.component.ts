import { Component } from '@angular/core'

@Component({
  selector: 'cui-topbar-project-management',
  templateUrl: './project-management.component.html',
  styleUrls: ['./project-management.component.scss'],
})
export class TopbarProjectManagementComponent {}
