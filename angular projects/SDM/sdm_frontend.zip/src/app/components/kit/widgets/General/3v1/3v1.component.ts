import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-3v1',
  templateUrl: './3v1.component.html',
})
export class CuiGeneral3v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
