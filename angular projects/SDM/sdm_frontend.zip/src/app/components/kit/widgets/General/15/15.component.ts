import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-15',
  templateUrl: './15.component.html',
})
export class CuiGeneral15Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
