import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-21',
  templateUrl: './21.component.html',
})
export class CuiGeneral21Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
