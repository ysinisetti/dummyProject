import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-21v3',
  templateUrl: './21v3.component.html',
})
export class CuiGeneral21v3Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
