import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-13v1',
  templateUrl: './13v1.component.html',
  styleUrls: ['./13v1.component.scss'],
})
export class CuiGeneral13v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
