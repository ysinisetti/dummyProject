import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-11',
  templateUrl: './11.component.html',
  styleUrls: ['./11.component.scss'],
})
export class CuiGeneral11Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
