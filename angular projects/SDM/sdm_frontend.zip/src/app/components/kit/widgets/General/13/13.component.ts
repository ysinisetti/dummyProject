import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-13',
  templateUrl: './13.component.html',
  styleUrls: ['./13.component.scss'],
})
export class CuiGeneral13Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
