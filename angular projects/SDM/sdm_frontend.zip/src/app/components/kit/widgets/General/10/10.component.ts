import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-10',
  templateUrl: './10.component.html',
  styleUrls: ['./10.component.scss'],
})
export class CuiGeneral10Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
