import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-14',
  templateUrl: './14.component.html',
  styleUrls: ['./14.component.scss'],
})
export class CuiGeneral14Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
