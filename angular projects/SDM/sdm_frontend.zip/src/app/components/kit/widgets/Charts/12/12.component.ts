import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-chart-12',
  templateUrl: './12.component.html',
})
export class CuiChart12Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
