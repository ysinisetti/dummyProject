import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-6v1',
  templateUrl: './6v1.component.html',
  styleUrls: ['./6v1.component.scss'],
})
export class CuiGeneral6v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
