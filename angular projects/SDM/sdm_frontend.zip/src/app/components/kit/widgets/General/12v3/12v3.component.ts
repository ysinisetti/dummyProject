import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-12v3',
  templateUrl: './12v3.component.html',
})
export class CuiGeneral12v3Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
