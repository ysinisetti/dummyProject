import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-24',
  templateUrl: './24.component.html',
})
export class CuiGeneral24Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
