import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-21v1',
  templateUrl: './21v1.component.html',
})
export class CuiGeneral21v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
