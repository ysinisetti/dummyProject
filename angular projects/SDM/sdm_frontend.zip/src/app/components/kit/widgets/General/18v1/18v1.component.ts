import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-18v1',
  templateUrl: './18v1.component.html',
})
export class CuiGeneral18v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
