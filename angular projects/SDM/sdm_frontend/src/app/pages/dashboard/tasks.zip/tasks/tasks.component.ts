import { DataService } from 'src/app/data.service'
import { Component, OnInit } from '@angular/core'
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { Router } from '@angular/router'
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop'
import { apis } from 'src/app/api'

export interface Tasks {
  key: string
  taskName: string
  level?: number
  expand?: boolean
  children?: Tasks[]
  parent?: Tasks
  duration: number
  startDate?: string
  endDate?: string

}

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss'],
})
export class TasksComponent implements OnInit {
  inputValue?: string
  isVisible = false
  isVisible1 = false
  searchTask: any
  addResourceForm: FormGroup
  editResourceForm: FormGroup
  taskDetails: any
  visible=false
  id: any
  parentId: any
  seqNo: any
  description: any
  createdBy: any
  projectId: any
  modifiedDate: any
  modifiedBy: any
  Date: any
  assignedTo: any
  type: any
  createdDate: any
  edDate
  predecessors: any
  storyId: any
  status: any
  priority: any
  loginId = JSON.parse(sessionStorage.getItem('loginData')).LoginId;

  tableData = [
    {
      taskName: 'Scoop Text',
      assignedTo: 'Jyothsna',
      priority: 'Internal',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '60 Days',
      notes: '',
      status: 'Active',
    },
    {
      taskName: 'Hubble',
      assignedTo: 'Jyothsna',
      priority: 'Internal',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '90 Days',
      notes: '',
      status: 'Active',
    },
    {
      taskName: 'Request Management',
      assignedTo: 'Jyothsna',
      priority: 'DMass',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '120 Days',
      notes: '',
      status: 'Active',
    },
    {
      taskName: 'Task Managment',
      assignedTo: 'Jyothsna',
      priority: 'JBHunt',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '120 Days',
      notes: '',
      status: 'In-Active',
    },
    {
      taskName: 'Risk Management',
      assignedTo: 'Jyothsna',
      priority: 'Miracle',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '60 Days',
      notes: '',
      status: 'Active',
    },
    {
      taskName: 'Project Manager',
      assignedTo: 'Jyothsna',
      priority: 'Miracle',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '90 Days',
      notes: '',
      status: 'In-Active',
    },
    {
      taskName: 'BPM',
      assignedTo: 'Jyothsna',
      priority: 'Internal',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '45 Days',
      notes: '',
      status: 'In-Active',
    },
    {
      taskName: 'Meeting Manager',
      assignedTo: 'Jyothsna',
      priority: 'DMass',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '30 Days',
      notes: '',
      status: 'Active',
    },
    {
      taskName: 'Gentex Inc',
      assignedTo: 'Jyothsna',
      priority: 'Internal',
      startDate: '08-08-2020',
      endDate: '08-10-2020',
      duration: '60 Days',
      notes: '',
      status: 'Active',
    },
  ]

  listOfMapData: Tasks[] = [
    {
      key: `1`,
      taskName: 'Hubble',
      startDate: '08-08-2020',
      endDate: '08-09-2020',
      duration: 30,
      children: [
        {
          key: `1-1`,
          taskName: 'sub-task3',
          startDate: '08-08-2020',
          endDate: '08-09-2020',
          duration: 22,

          children: [
            {
              key: `1-1-1`,
              taskName: 'milestone',
              startDate: '08-08-2020',
              endDate: '08-09-2020',
              duration: 33,

              children: [
                {
                  key: `1-1-1-1`,
                  taskName: 'task1',
                  startDate: '08-08-2020',
                  endDate: '08-09-2020',
                  duration: 44,
                },
                {
                  key: `1-1-1-2`,
                  taskName: 'task2',
                  startDate: '08-08-2020',
                  endDate: '08-09-2020',
                  duration: 11,
                },
              ],
            },
          ],
        },
      ],
    },
  ]
  mapOfExpandedData: { [key: string]: Tasks[] } = {}
  arr: {
    taskName: string
    priority: string
    startDate: string
    endDate: string
    duration: string
    notes: string
    status: string
  }[]
  taskData: {
    taskName: string
    priority: string
    startDate: string
    endDate: string
    duration: string
    notes: string
    status: string
  }[]
  duplicateAry: {
    taskName: string
    id: string
    priority: string
    startDate: string
    endDate: string
    duration: string
    notes: string
    status: string
  }[]
  filtered: {
    taskName: string
    priority: string
    startDate: string
    endDate: string
    duration: string
    notes: string
    status: string
  }[]

  collapse(array: Tasks[], data: Tasks, $event: boolean): void {
    if (!$event) {
      if (data.children) {
        data.children.forEach(d => {
          const target = array.find(a => a.key === d.key)!
          target.expand = false
          this.collapse(array, target, false)
        })
      } else {
        return
      }
    }
  }

  convertTreeToList(root: Tasks): Tasks[] {
    const stack: Tasks[] = []
    const array: Tasks[] = []
    const hashMap = {}
    stack.push({ ...root, level: 0, expand: false })

    while (stack.length !== 0) {
      const node = stack.pop()!
      this.visitNode(node, hashMap, array)
      if (node.children) {
        for (let i = node.children.length - 1; i >= 0; i--) {
          stack.push({ ...node.children[i], level: node.level! + 1, expand: false, parent: node })
        }
      }
    }

    return array
  }

  visitNode(node: Tasks, hashMap: { [key: string]: boolean }, array: Tasks[]): void {
    if (!hashMap[node.key]) {
      hashMap[node.key] = true
      array.push(node)
    }
  }
  addRow(): void {
    this.isVisible = true
  }
  constructor(private fb: FormBuilder, private router: Router, private dataService: DataService) {}

  ngOnInit(): void {
    this.editResourceForm = this.fb.group({
      taskName: [
        '',
        [Validators.required, Validators.maxLength(16), Validators.pattern('^[a-zA-z]*$')],
      ],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      duration: [null, Validators.required],
      notes: ['', Validators.required],
    })
    this.addResourceForm = this.fb.group({
      taskName1: ['', [Validators.required, Validators.maxLength(16), Validators.pattern('^[a-zA-z]*$')],
      ],
      startDate1: ['', Validators.required],
      endDate1: ['', Validators.required],
      duration1: [null, Validators.required],
      notes1: ['', Validators.required],
    })

    this.listOfMapData.forEach(item => {
      this.mapOfExpandedData[item.key] = this.convertTreeToList(item)
    })

    console.log(this.loginId);
    this.getAllTasks()
    //this.updateTask();
    // this.getGridData();
  }
  getAllTasks() {
    this.dataService.get(apis.todoGet).subscribe(res => {
      console.log(res)
      this.taskDetails = res
      console.log('Table Values', this.taskDetails)
    })
  }



  // getAllTasks() {
  //   let myTodos={
  //     "assignedTo": this.loginId,
  //     "projectId":this.pId
  //   }
  //   this.dataService.getTodo(apis.todoGet,myTodos).subscribe(res => {
  //     console.log(res)
  //     this.taskDetails = res
  //     console.log('Table Values', this.taskDetails)
  //   })
  // }

  editRow(values): void {
    console.log('edit row', values, this.editResourceForm.get('taskName').patchValue(values.Name))
    this.isVisible1 = true
    this.editResourceForm.get('taskName').patchValue(values.Name)
    this.editResourceForm.get('startDate').patchValue(values.StartDate)
    this.editResourceForm.get('endDate').patchValue(values.EndDate)
    this.editResourceForm.get('duration').patchValue(values.Duration)
    this.editResourceForm.get('notes').patchValue(values.Description)
  }

  deleteRow(id: string): void {
    this.listOfMapData = this.listOfMapData.filter(d => d.taskName !== id)
  }



  open(): void {
    this.visible = true;
  }


  handleCancel(): void {
    // console.log('Button cancel clicked!');
    this.isVisible = false
    this.isVisible1 = false
  }

  onSearch(event) {}

  save(): void {
    this.isVisible = true
    this.isVisible1 = true
  }

  reset(): void {
    this.searchTask = ''
    this.onSearch(this.searchTask)
  }

  // onSearch(value: string): void {
  //   console.log(value);
  //   this.listOfMapData = this.listOfMapData.filter((item: Tasks) => item.taskName.indexOf(this.searchTask) !== -1);
  // }

  // getGridData(){
  //   const gridData = {
  //       "taskName":  "",
  //       "startDate": "",
  //       "endDate": "",
  //       "duration": "",
  //     }
  //   }
  onCurrentPageDataChange(data) {
    console.log(data)
  }

  drop(event: CdkDragDrop<string[]>): void {
    moveItemInArray(this.listOfMapData, event.previousIndex, event.currentIndex)
  }
  submitForm() {
    console.log('submittred 123 edit166', this.addResourceForm)
  }

  submitForm1(x) {
    console.log('submittred 123 edit', this.editResourceForm, x)
  }
}
