import { DataService } from './../../../data.service'
import { Component, OnInit } from '@angular/core'
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { Tasks } from '../tasks/tasks.component'
import { Router } from '@angular/router'
import { apis } from 'src/app/api'

@Component({
  selector: 'app-releases',
  templateUrl: './releases.component.html',
  styleUrls: ['./releases.component.scss'],
})
export class ReleasesComponent implements OnInit {
  allResoursesDetails:any;

  visible = false
  inputValue?: string
  isVisible = false
  isVisible1 = false
  searchTask: any
  addResourceForm: FormGroup
  editResourceForm: FormGroup
  inputValue1?: string
  noteForm: FormGroup
  id: any
  projectId: any
  endTaskId: any
  releaseTag: any
  description1: any
  createdBy: any
  seqNo: any
  modifiedBy: any
  allRealeses: any
  pageSize = 2
  pageIndex = 1
  idToBeEdited:any;
  startDate:any;
  status: any
  SeqNo: any
  Description: any
  ProjectId: any
  CreateBy: any
  ModifiedDate: any
  ModifiedBy: any
  StartTaskId: any
  Version: any
  ReleaseEndDate: any
  ReleaseTag: any
  CreatedDate: any
  Id: any
  ReleaseStartDate: any
  EndTaskId: any


  open(): void {
    this.visible = true
  }

  close(): void {
    this.visible = false
  }


getAllRelease(){
  this.dataService.get(apis.getAllReleases).subscribe((res)=>{
  console.log("All Releases",res);
  this.allResoursesDetails = res;
  })
}

  getColor(status) {
    switch (status) {
      case 'IN PROGRESS':
        return '#00aae7'
      case 'UNRELEASED':
        return '#f58142'
      case 'RELEASED':
        return '#00ff2f'
    }
  }




  addRow(): void {
    this.isVisible = true
  }
  ngOnInit(): void {
    // this.loadDataFromServer(this.pageIndex, this.pageSize, null, null, []);

    this.editResourceForm = this.fb.group({
      version: [ '',[Validators.required, Validators.maxLength(6), Validators.pattern('^[0-9]{1,2}\d*(\.[0-9]{1}\d*)\d*(\.[0-9]{1}\d*)$')]],
     // startDate: ['', Validators.required],
      releaseDate: ['', Validators.required],
      status: ['', Validators.required],
      description: [''],
    })
    // (([1-9]+\d*\.)+[1-9]+\d*)|[1-9]+\d*
    // +.[0-9]{1}+.[0-9]{1}
    this.addResourceForm = this.fb.group({
      version1: ['', [Validators.required, Validators.maxLength(6), Validators.pattern('^[0-9]{1,2}\d*(\.[0-9]{1}\d*)\d*(\.[0-9]{1}\d*)$')]],
      startDate1: ['', Validators.required],
      releaseDate1: ['', Validators.required],
      status1: ['', Validators.required],
      description1: ['', Validators.required],
    })
    // this.noteForm = this.fb.group({
    //   notes : ['',[Validators.required, Validators.maxLength(250),Validators.pattern('^[a-zA-z]*$')]]
    // })

    this.getAllRelease();
  }

  editRow(values): void {
    this.idToBeEdited =values.Id,
    this.startDate=values.StartDate,
//console.log("idToBeEdited",this.idToBeEdited);

    console.log('edit row', values, this.editResourceForm.get('version').patchValue(values.Version))
    this.isVisible1 = true

    this.editResourceForm.get('version').patchValue(values.Version)
    //this.editResourceForm.get('startDate').patchValue(values.startDate)
    this.editResourceForm.get('releaseDate').patchValue(values.ReleaseEndDate)
    this.editResourceForm.get('status').patchValue(values.Status)
    this.editResourceForm.get('description').patchValue(values.Description)
  }

  deleteRow(id): void {
    let dId ={
      "id":id
    }
   // this.allResoursesDetails = this.allResoursesDetails.filter(d => d.taskName !== id);
this.dataService.post(apis.deleteReleases,dId).subscribe((res)=>{
console.log("deleted");
console.log(res);

})
  }


  handleSubmit1() {
   // this.Status = "InActive"
    this.SeqNo= 7
    this.ProjectId= 45
    this.CreateBy = "jdasari"
   // this.ModifiedDate= "08-22-2020"
    this.ModifiedBy= "arelli"
    this.StartTaskId= 7
    this.Version= 1
    this.ReleaseTag= "done"
    this.Id= 1
    this.EndTaskId= 8

    let postReleases={
        "status" :  this.addResourceForm.controls.status1.value,
        "seqNo" : this.SeqNo,
        "description" :this.addResourceForm.controls.description1.value,
        "projectId" :this.ProjectId,
        "createdBy" :this.CreateBy,
       // "ModifiedDate" :this.addResourceForm.controls.status1.value,
        "modifiedBy" :this.ModifiedBy,
        "startTaskId" :this.StartTaskId,
        "version" :this.addResourceForm.controls.version1.value,
        "releaseEndDate" :this.addResourceForm.controls.releaseDate1.value,
        "releaseTag" :this.ReleaseTag,
       // "CreatedDate" :this.addResourceForm.controls.status1.value,
       // "id" :this.Id,
       "releaseStartDate" :this.addResourceForm.controls.startDate1.value,
        "endTaskId" :this.EndTaskId
    }
   this.dataService.post(apis.releasesPost,postReleases).subscribe((res)=>{
     console.log("releases rsponse", res);

console.log("Add new Release", postReleases);

   })
    console.log('--->data to table', postReleases)
    this.isVisible = false
  }

  updateTask() {
       this.SeqNo= 7
       this.ProjectId= 45
        this.CreateBy = "jdasari"
        this.ModifiedBy= "arelli"
        this.StartTaskId= 7
        this.Version= 1
        this.ReleaseTag= "done"
        this.EndTaskId= 8
    let updated = {
      "id" :this.idToBeEdited,
      "status" :  this.editResourceForm.controls.status.value,
      "seqNo" : this.SeqNo,
      "description" :this.editResourceForm.controls.description.value,
      "projectId" :this.ProjectId,
      "createdBy" :this.CreateBy,
      "modifiedBy" :this.ModifiedBy,
      "startTaskId" :this.StartTaskId,
      "version" :this.editResourceForm.controls.version.value,
      "releaseEndDate" :this.editResourceForm.controls.releaseDate.value,
      "releaseTag" :this.ReleaseTag,
      "releaseStartDate" :this.startDate,
      "endTaskId" :this.EndTaskId
    }
    this.dataService.post(apis.updateReleases,updated).subscribe((res)=>{
      console.log("updating Releases",res);
    })
    console.log('--->data to table', updated)

    this.isVisible1 = false
  }

  handleCancel(): void {
    this.isVisible = false
    this.isVisible1 = false
  }

  onSearch(event) {}

  save(): void {
    this.isVisible = true
    this.isVisible1 = true
  }

  reset(): void {
    this.searchTask = ''
    this.onSearch(this.searchTask)
  }

  constructor(private fb: FormBuilder, private router: Router, private dataService: DataService) {}

  onCurrentPageDataChange(data) {
    console.log(data)
  }

  submitForm() {
    console.log('submittred 123 edit166', this.addResourceForm)
  }

  submitForm1(x) {
    console.log('submittred 123 edit', this.editResourceForm, x)
  }
}


//(ProjectId,StartTaskId,EndTaskId,ReleaseStartDate,ReleaseEndDate,ReleaseTag,SeqNo,Description,CreatedBy,ModifiedBy)
