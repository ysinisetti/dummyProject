import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { apis } from 'src/app/api';



interface Projects {
  key: string;
  startDate: string;
  endDate: string;
  duration: number;
  projectName: string;
  customerName: string
}

@Component({
  selector: 'app-all-projects',
  templateUrl: './all-projects.component.html',
  styleUrls: ['./all-projects.component.scss']
})
export class AllProjectsComponent implements OnInit {
  isVisible=false;
  addResourceForm: FormGroup;
  searchTask:any;
  listOfData:any;

  records:any;

  id = 60;
projectName:any;
customerName:any;
duration:any;
startDate:any;
endDate:any;
ModifiedDate:any;


// "Id":,
// "ProjectName":,
// "CustomerName":,
// "Duration":,
// "StartDate":,
// "EndDate":,
// "ModifiedDate":,

constructor(private route : Router,private fb:FormBuilder, private dataService :DataService){}

ngOnInit(){
  this.addResourceForm = this.fb.group({
    projectName : ['', [Validators.required, Validators.maxLength(16),Validators.pattern('^[a-zA-z]*$')]],
    customerName : ['', [Validators.required, Validators.maxLength(16),Validators.pattern('^[a-zA-z]*$')]],
    id : ['',[Validators.required, Validators.maxLength(3),Validators.pattern('^[0-9]{1,3}$')]],
    endDate1 : ['', Validators.required],
  });
  this.getAllProjects();
}


details(name){
console.log("clicked");
this.route.navigate(['/dashboard/projectDetails',name]);
}

getAllProjects(){
  this.dataService.get(apis.allProjects).subscribe((res)=>{
this.listOfData =res;
this.records=res.length;
console.log("All Projects ",this.listOfData);
  });

}




  addRow(){
    this.isVisible = true;
  }

handleSubmit1(){


this.duration=20;
 let addProject={
"id": this.addResourceForm.controls.id.value,
"projectName":this.addResourceForm.controls.projectName.value,
"customerName":this.addResourceForm.controls.customerName.value,
"duration":this.duration,
"endDate":this.addResourceForm.controls.endDate1.value,
  }
  this.dataService.post(apis.postNewProject,addProject).subscribe((res)=>{
    console.log("post new project",res);
    console.log("", addProject);

  });
  this.getAllProjects();
  this.isVisible = false;

}
handleCancel(): void {
this.isVisible = false;
}
}





