import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-7',
  templateUrl: './7.component.html',
  styleUrls: ['./7.component.scss'],
})
export class CuiList7Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
