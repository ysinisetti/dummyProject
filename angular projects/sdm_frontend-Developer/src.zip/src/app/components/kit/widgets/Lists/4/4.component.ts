import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-4',
  templateUrl: './4.component.html',
  styleUrls: ['./4.component.scss'],
})
export class CuiList4Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
