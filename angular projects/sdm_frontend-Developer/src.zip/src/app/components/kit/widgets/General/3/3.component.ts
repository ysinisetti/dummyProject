import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-3',
  templateUrl: './3.component.html',
})
export class CuiGeneral3Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
