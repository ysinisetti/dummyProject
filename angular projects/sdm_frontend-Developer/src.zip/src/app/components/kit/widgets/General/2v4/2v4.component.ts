import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-2v4',
  templateUrl: './2v4.component.html',
})
export class CuiGeneral2v4Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
