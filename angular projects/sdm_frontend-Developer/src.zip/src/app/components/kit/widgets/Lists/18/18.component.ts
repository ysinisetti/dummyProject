import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-18',
  templateUrl: './18.component.html',
  styleUrls: ['./18.component.scss'],
})
export class CuiList18Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
