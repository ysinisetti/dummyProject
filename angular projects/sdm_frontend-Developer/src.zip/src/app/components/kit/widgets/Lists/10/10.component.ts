import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-10',
  templateUrl: './10.component.html',
  styleUrls: ['./10.component.scss'],
})
export class CuiList10Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
