import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-9',
  templateUrl: './9.component.html',
  styleUrls: ['./9.component.scss'],
})
export class CuiList9Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
