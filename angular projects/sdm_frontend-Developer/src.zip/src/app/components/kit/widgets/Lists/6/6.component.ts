import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-6',
  templateUrl: './6.component.html',
  styleUrls: ['./6.component.scss'],
})
export class CuiList6Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
