import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-5',
  templateUrl: './5.component.html',
})
export class CuiGeneral5Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
