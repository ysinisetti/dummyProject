import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-15',
  templateUrl: './15.component.html',
  styleUrls: ['./15.component.scss'],
})
export class CuiList15Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
