import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-5v1',
  templateUrl: './5v1.component.html',
})
export class CuiGeneral5v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
