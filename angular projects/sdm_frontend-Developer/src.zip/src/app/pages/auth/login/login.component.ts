import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-login-page',
  templateUrl: './login.component.html',
})
export class LoginPage {}
