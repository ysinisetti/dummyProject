import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-forgot-password-page',
  templateUrl: './forgot-password.component.html',
})
export class ForgotPasswordPage {}
