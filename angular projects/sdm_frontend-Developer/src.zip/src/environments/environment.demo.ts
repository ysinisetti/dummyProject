export const environment = {
  production: true,
  authenticated: true,
  hmr: false,
}
