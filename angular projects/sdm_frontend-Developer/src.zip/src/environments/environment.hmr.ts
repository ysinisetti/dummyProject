export const environment = {
  production: false,
  authenticated: false,
  hmr: true,
}
