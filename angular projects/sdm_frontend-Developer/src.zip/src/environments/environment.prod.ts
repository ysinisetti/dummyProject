export const environment = {
  production: true,
  authenticated: false,
  hmr: false,
}
