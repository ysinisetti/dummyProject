import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-lockscreen',
  templateUrl: './lockscreen.component.html',
  styleUrls: ['../style.component.scss'],
})
export class LockscreenComponent {}
