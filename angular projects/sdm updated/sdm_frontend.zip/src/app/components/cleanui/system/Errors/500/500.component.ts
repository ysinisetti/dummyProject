import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-500',
  templateUrl: './500.component.html',
})
export class Error500Component {}
