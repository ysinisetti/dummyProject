import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-24v1',
  templateUrl: './24v1.component.html',
})
export class CuiGeneral24v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
