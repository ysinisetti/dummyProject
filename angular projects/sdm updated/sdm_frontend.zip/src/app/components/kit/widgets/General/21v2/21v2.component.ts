import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-21v2',
  templateUrl: './21v2.component.html',
})
export class CuiGeneral21v2Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
