import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-11',
  templateUrl: './11.component.html',
  styleUrls: ['./11.component.scss'],
})
export class CuiList11Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
