import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-1',
  templateUrl: './1.component.html',
})
export class CuiGeneral1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
