import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-7',
  templateUrl: './7.component.html',
})
export class CuiGeneral7Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
