import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-12',
  templateUrl: './12.component.html',
})
export class CuiGeneral12Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
