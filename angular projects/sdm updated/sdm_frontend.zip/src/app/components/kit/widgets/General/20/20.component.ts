import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-20',
  templateUrl: './20.component.html',
  styleUrls: ['./20.component.scss'],
})
export class CuiGeneral20Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
