import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-12v1',
  templateUrl: './12v1.component.html',
})
export class CuiGeneral12v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
