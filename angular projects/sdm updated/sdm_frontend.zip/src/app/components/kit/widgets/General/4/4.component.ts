import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-4',
  templateUrl: './4.component.html',
})
export class CuiGeneral4Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
