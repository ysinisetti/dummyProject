import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-18',
  templateUrl: './18.component.html',
})
export class CuiGeneral18Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
