import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-20',
  templateUrl: './20.component.html',
  styleUrls: ['./20.component.scss'],
})
export class CuiList20Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
