import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-list-5',
  templateUrl: './5.component.html',
  styleUrls: ['./5.component.scss'],
})
export class CuiList5Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
