import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'kit-general-17v1',
  templateUrl: './17v1.component.html',
  styleUrls: ['./17v1.component.scss'],
})
export class CuiGeneral17v1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
