import { Component } from '@angular/core'

@Component({
  selector: 'cui-system-500-page',
  templateUrl: './500.component.html',
})
export class Error500Page {}
