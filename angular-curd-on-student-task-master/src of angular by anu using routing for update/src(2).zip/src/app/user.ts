export class User{
    constructor(
        firstname:String, 
        lastname:String,
        phonenumber:number,
        email:String
        
       
    
    ){}
}