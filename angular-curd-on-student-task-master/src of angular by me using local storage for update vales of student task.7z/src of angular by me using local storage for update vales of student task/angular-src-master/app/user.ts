export class User {
    id:BigInteger;
    student_name:string;
    student_branch:string;

    college_name:string;
    college_code:BigInteger

    PhoneNum: BigInteger;
    email:string;
}
