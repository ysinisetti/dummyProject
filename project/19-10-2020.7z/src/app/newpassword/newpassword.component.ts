import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-newpassword',
  templateUrl: './newpassword.component.html',
  styleUrls: ['./newpassword.component.scss']
})
export class NewpasswordComponent implements OnInit {
    newpasswordForm: FormGroup;
    hide: boolean = true;



  constructor(private ff: FormBuilder,private snackBar:MatSnackBar) { }

  ngOnInit() {
    this.newpasswordForm = this.ff.group({
      otpNumber:[''],
      password: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(8), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&#])[A-Za-z\d$@$!%*?&].{7,}')]],
      cpassword: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(8), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&#])[A-Za-z\d$@$!%*?&].{7,}')]],
  })
 

}
submit(){
  this.snackBar.open('Your password changed successfully.','', {duration: 50, });
}

}
