import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.scss']
})
export class ForgotpasswordComponent implements OnInit {
  hide: boolean = true;
  forgotForm: FormGroup;



  constructor(private router: Router,private tt: FormBuilder,private snackBar:MatSnackBar) { }
next()
{
  this.router.navigate(["new"])
  this.snackBar.open('Please check your mail','Ok', {
    // verticalPosition: 'top',
    duration: 1000,
    panelClass: ['green-snackbar']

  });
}
  ngOnInit(): void {
    this.forgotForm = this.tt.group({

    userName: ['', [Validators.required, Validators.maxLength(30), Validators.minLength(3), Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
   
  });
 


}
}
